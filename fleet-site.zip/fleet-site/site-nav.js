(() => {
    const body = document.body;
    const header = document.querySelector(".site-header");
    if (!body || !header) return;
    const currentFileName = (window.location.pathname.split("/").pop() || "index.html").toLowerCase();
    const homeHref = "index.html";

    const inferPage = () => {
        if (body.dataset.navPage) return body.dataset.navPage;

        const pageMap = {
            "": "home",
            "index.html": "home",
            "random.html": "home",
            "integrated-services.html": "services",
            "customers-approvals.html": "customers",
            "company.html": "company",
            "suppliers.html": "suppliers"
        };

        return pageMap[currentFileName] || "home";
    };

    const navMarkup = `
<div class="site-frame">
<div class="nav-shell">
<a aria-label="Fleet Canada home" class="nav-brand" href="${homeHref}">
<img alt="Fleet Canada" class="nav-brand-logo" src="fleetLogo.svg"/>
</a>
<nav aria-label="Primary" class="nav-desktop">
<div class="nav-dropdown" data-nav-item="capabilities">
<button aria-expanded="false" class="nav-trigger" type="button">
<span>Capabilities</span>
<span aria-hidden="true" class="nav-caret material-symbols-outlined">expand_more</span>
</button>
<div class="nav-panel">
<div class="nav-panel-card nav-panel-card--wide">
<span class="nav-panel-kicker">Capabilities</span>
<p class="nav-panel-title">Core manufacturing disciplines built to support demanding aerospace structures.</p>
<div class="nav-panel-grid nav-panel-grid--capabilities">
<a class="nav-dropdown-link" href="company.html#capability-structural-assemblies"><span class="nav-dropdown-copy"><span class="nav-dropdown-link-label">Structural Assemblies</span><span class="nav-dropdown-link-note">Build-to-print assembly execution</span></span><span aria-hidden="true" class="nav-link-arrow material-symbols-outlined">arrow_outward</span></a>
<a class="nav-dropdown-link" href="company.html#capability-processing"><span class="nav-dropdown-copy"><span class="nav-dropdown-link-label">Processing</span><span class="nav-dropdown-link-note">Production flow and process support</span></span><span aria-hidden="true" class="nav-link-arrow material-symbols-outlined">arrow_outward</span></a>
<a class="nav-dropdown-link" href="company.html#capability-composites"><span class="nav-dropdown-copy"><span class="nav-dropdown-link-label">Composites</span><span class="nav-dropdown-link-note">Composite part manufacturing capability</span></span><span aria-hidden="true" class="nav-link-arrow material-symbols-outlined">arrow_outward</span></a>
<a class="nav-dropdown-link" href="company.html#capability-metal-to-metal-bonding"><span class="nav-dropdown-copy"><span class="nav-dropdown-link-label">Metal to Metal Bonding</span><span class="nav-dropdown-link-note">Bonding and joining expertise</span></span><span aria-hidden="true" class="nav-link-arrow material-symbols-outlined">arrow_outward</span></a>
<a class="nav-dropdown-link" href="company.html#capability-aluminum-component-fabrication"><span class="nav-dropdown-copy"><span class="nav-dropdown-link-label">Aluminum Component Fabrication</span><span class="nav-dropdown-link-note">Fabrication and detail part work</span></span><span aria-hidden="true" class="nav-link-arrow material-symbols-outlined">arrow_outward</span></a>
<a class="nav-dropdown-link" href="company.html#capability-inspection"><span class="nav-dropdown-copy"><span class="nav-dropdown-link-label">Inspection</span><span class="nav-dropdown-link-note">Quality verification systems</span></span><span aria-hidden="true" class="nav-link-arrow material-symbols-outlined">arrow_outward</span></a>
<a class="nav-dropdown-link" href="company.html#capability-laboratory"><span class="nav-dropdown-copy"><span class="nav-dropdown-link-label">Laboratory</span><span class="nav-dropdown-link-note">Testing and lab support</span></span><span aria-hidden="true" class="nav-link-arrow material-symbols-outlined">arrow_outward</span></a>
</div>
</div>
</div>
</div>
<a class="nav-link" data-nav-item="services" href="integrated-services.html">Integrated Services</a>
<div class="nav-dropdown" data-nav-item="customers">
<button aria-expanded="false" class="nav-trigger" type="button">
<span>Customers and Approvals</span>
<span aria-hidden="true" class="nav-caret material-symbols-outlined">expand_more</span>
</button>
<div class="nav-panel">
<div class="nav-panel-card">
<span class="nav-panel-kicker">Customers and Approvals</span>
<p class="nav-panel-title">Customer confidence built through long-term partnerships, approvals, and proven program delivery.</p>
<div class="nav-panel-grid">
<a class="nav-dropdown-link" href="customers-approvals.html#customers-accolades"><span class="nav-dropdown-copy"><span class="nav-dropdown-link-label">Customers &amp; Accolades</span><span class="nav-dropdown-link-note">Relationships built over decades</span></span><span aria-hidden="true" class="nav-link-arrow material-symbols-outlined">arrow_outward</span></a>
<a class="nav-dropdown-link" href="customers-approvals.html#certifications-approvals"><span class="nav-dropdown-copy"><span class="nav-dropdown-link-label">Certifications &amp; Approvals</span><span class="nav-dropdown-link-note">Quality systems and approvals</span></span><span aria-hidden="true" class="nav-link-arrow material-symbols-outlined">arrow_outward</span></a>
<a class="nav-dropdown-link" href="customers-approvals.html#program-gallery"><span class="nav-dropdown-copy"><span class="nav-dropdown-link-label">Program Gallery</span><span class="nav-dropdown-link-note">Commercial, civilian, and military work</span></span><span aria-hidden="true" class="nav-link-arrow material-symbols-outlined">arrow_outward</span></a>
</div>
</div>
</div>
</div>
<div class="nav-dropdown" data-nav-item="company">
<button aria-expanded="false" class="nav-trigger" type="button">
<span>Company</span>
<span aria-hidden="true" class="nav-caret material-symbols-outlined">expand_more</span>
</button>
<div class="nav-panel">
<div class="nav-panel-card">
<span class="nav-panel-kicker">Company</span>
<p class="nav-panel-title">Learn who Fleet is, the people behind the work, and where the company is headed.</p>
<div class="nav-panel-grid">
<a class="nav-dropdown-link" href="company.html#about-us"><span class="nav-dropdown-copy"><span class="nav-dropdown-link-label">About Us</span><span class="nav-dropdown-link-note">Heritage, culture, and mission</span></span><span aria-hidden="true" class="nav-link-arrow material-symbols-outlined">arrow_outward</span></a>
<a class="nav-dropdown-link" href="company.html#team"><span class="nav-dropdown-copy"><span class="nav-dropdown-link-label">Team</span><span class="nav-dropdown-link-note">People and operational leadership</span></span><span aria-hidden="true" class="nav-link-arrow material-symbols-outlined">arrow_outward</span></a>
<a class="nav-dropdown-link" href="company.html#careers"><span class="nav-dropdown-copy"><span class="nav-dropdown-link-label">Careers</span><span class="nav-dropdown-link-note">Join the next chapter</span></span><span aria-hidden="true" class="nav-link-arrow material-symbols-outlined">arrow_outward</span></a>
</div>
</div>
</div>
</div>
<a class="nav-link" data-nav-item="suppliers" href="suppliers.html">Suppliers</a>
</nav>
<div class="nav-actions">
<a class="nav-cta nav-cta-desktop" href="#get-in-touch">Get in touch</a>
<button aria-controls="mobile-site-nav" aria-expanded="false" aria-label="Open menu" class="mobile-nav-toggle" data-mobile-nav-toggle type="button">
<span aria-hidden="true" class="material-symbols-outlined" data-mobile-nav-icon>menu</span>
<span class="mobile-nav-label">Menu</span>
</button>
</div>
</div>
</div>
<div class="mobile-nav-shell" data-mobile-nav hidden id="mobile-site-nav">
<button aria-label="Close menu" class="mobile-nav-backdrop" data-mobile-nav-close type="button"></button>
<div class="mobile-nav-frame">
<div class="mobile-nav-header">
<div class="mobile-nav-brand">
<img alt="Fleet Canada" class="mobile-nav-logo" src="fleetLogo.svg"/>
<div>
<span class="mobile-nav-brandline">Navigation</span>
<p class="mobile-nav-meta">Fleet Canada</p>
</div>
</div>
<button class="mobile-nav-close" data-mobile-nav-close type="button">
<span aria-hidden="true" class="material-symbols-outlined">close</span>
<span class="sr-only">Close menu</span>
</button>
</div>
<div class="mobile-nav-scroll">
<nav aria-label="Mobile primary" class="mobile-nav-list">
<details class="mobile-nav-group" data-nav-item="capabilities">
<summary class="mobile-nav-summary"><span class="mobile-nav-summary-copy"><strong>Capabilities</strong><span>Explore our core manufacturing disciplines</span></span><span aria-hidden="true" class="material-symbols-outlined">expand_more</span></summary>
<div class="mobile-nav-submenu">
<a class="mobile-nav-sublink" href="company.html#capability-structural-assemblies"><span>Structural Assemblies</span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
<a class="mobile-nav-sublink" href="company.html#capability-processing"><span>Processing</span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
<a class="mobile-nav-sublink" href="company.html#capability-composites"><span>Composites</span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
<a class="mobile-nav-sublink" href="company.html#capability-metal-to-metal-bonding"><span>Metal to Metal Bonding</span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
<a class="mobile-nav-sublink" href="company.html#capability-aluminum-component-fabrication"><span>Aluminum Component Fabrication</span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
<a class="mobile-nav-sublink" href="company.html#capability-inspection"><span>Inspection</span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
<a class="mobile-nav-sublink" href="company.html#capability-laboratory"><span>Laboratory</span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
</div>
</details>
<a class="mobile-nav-link" data-nav-item="services" href="integrated-services.html"><span class="mobile-nav-link-copy"><strong>Integrated Services</strong><span>Planning, tooling, and program management</span></span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
<details class="mobile-nav-group" data-nav-item="customers">
<summary class="mobile-nav-summary"><span class="mobile-nav-summary-copy"><strong>Customers and Approvals</strong><span>Relationships, approvals, and programs</span></span><span aria-hidden="true" class="material-symbols-outlined">expand_more</span></summary>
<div class="mobile-nav-submenu">
<a class="mobile-nav-sublink" href="customers-approvals.html#customers-accolades"><span>Customers &amp; Accolades</span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
<a class="mobile-nav-sublink" href="customers-approvals.html#certifications-approvals"><span>Certifications &amp; Approvals</span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
<a class="mobile-nav-sublink" href="customers-approvals.html#program-gallery"><span>Program Gallery</span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
</div>
</details>
<details class="mobile-nav-group" data-nav-item="company">
<summary class="mobile-nav-summary"><span class="mobile-nav-summary-copy"><strong>Company</strong><span>About Fleet, the team, and careers</span></span><span aria-hidden="true" class="material-symbols-outlined">expand_more</span></summary>
<div class="mobile-nav-submenu">
<a class="mobile-nav-sublink" href="company.html#about-us"><span>About Us</span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
<a class="mobile-nav-sublink" href="company.html#team"><span>Team</span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
<a class="mobile-nav-sublink" href="company.html#careers"><span>Careers</span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
</div>
</details>
<a class="mobile-nav-link" data-nav-item="suppliers" href="suppliers.html"><span class="mobile-nav-link-copy"><strong>Suppliers</strong><span>Quality expectations and download resources</span></span><span aria-hidden="true" class="material-symbols-outlined">arrow_outward</span></a>
</nav>
</div>
<a class="mobile-nav-cta" href="#get-in-touch">Get in touch</a>
</div>
</div>`;

    header.setAttribute("data-site-header", "true");
    header.innerHTML = navMarkup;
    body.dataset.navPage = inferPage();

    const desktopDropdowns = Array.from(document.querySelectorAll(".nav-dropdown"));
    const mobileNav = document.querySelector("[data-mobile-nav]");
    const mobileToggle = document.querySelector("[data-mobile-nav-toggle]");
    const mobileIcon = document.querySelector("[data-mobile-nav-icon]");
    const mobileCloseButtons = Array.from(document.querySelectorAll("[data-mobile-nav-close]"));
    const mobileGroups = Array.from(document.querySelectorAll(".mobile-nav-group"));
    const desktopNavItems = Array.from(document.querySelectorAll(".nav-desktop [data-nav-item]"));
    const mobileNavItems = Array.from(document.querySelectorAll(".mobile-nav-list [data-nav-item]"));
    const desktopTriggers = Array.from(document.querySelectorAll(".nav-trigger"));
    const largeViewport = window.matchMedia("(min-width: 1024px)");
    let mobileHideTimer = null;

    const getActiveNavItem = () => {
        const page = body.dataset.navPage || inferPage();
        const hash = window.location.hash || "";

        if (page === "company" && hash.startsWith("#capability-")) {
            return "capabilities";
        }

        switch (page) {
            case "services":
                return "services";
            case "customers":
                return "customers";
            case "company":
                return "company";
            case "suppliers":
                return "suppliers";
            default:
                return "";
        }
    };

    const syncActiveState = () => {
        const active = getActiveNavItem();

        desktopNavItems.forEach((item) => {
            const isActive = item.dataset.navItem === active;
            item.classList.toggle("is-active", isActive);

            if (item.tagName === "A") {
                if (isActive) {
                    item.setAttribute("aria-current", "page");
                } else {
                    item.removeAttribute("aria-current");
                }
            }
        });

        mobileNavItems.forEach((item) => {
            const isActive = item.dataset.navItem === active;
            item.classList.toggle("is-active", isActive);

            if (item.tagName === "A") {
                if (isActive) {
                    item.setAttribute("aria-current", "page");
                } else {
                    item.removeAttribute("aria-current");
                }
            }

            if (item instanceof HTMLDetailsElement && isActive) {
                item.open = true;
            }
        });
    };

    const setDesktopExpanded = (dropdown, expanded) => {
        const trigger = dropdown.querySelector(".nav-trigger");
        if (trigger) {
            trigger.setAttribute("aria-expanded", expanded ? "true" : "false");
        }
    };

    desktopDropdowns.forEach((dropdown) => {
        dropdown.addEventListener("pointerenter", () => setDesktopExpanded(dropdown, true));
        dropdown.addEventListener("pointerleave", () => setDesktopExpanded(dropdown, false));
        dropdown.addEventListener("focusin", () => setDesktopExpanded(dropdown, true));
        dropdown.addEventListener("focusout", () => {
            window.requestAnimationFrame(() => {
                setDesktopExpanded(dropdown, dropdown.contains(document.activeElement));
            });
        });
    });

    const syncMobileToggle = (isOpen) => {
        if (!mobileToggle) return;

        mobileToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
        mobileToggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");

        if (mobileIcon) {
            mobileIcon.textContent = isOpen ? "close" : "menu";
        }
    };

    const setMobileMenuOpen = (isOpen) => {
        if (!mobileNav || !mobileToggle) return;

        if (mobileHideTimer) {
            window.clearTimeout(mobileHideTimer);
            mobileHideTimer = null;
        }

        if (isOpen) {
            mobileNav.hidden = false;
            window.requestAnimationFrame(() => {
                mobileNav.dataset.open = "true";
            });
            body.classList.add("nav-menu-open");
            syncMobileToggle(true);
            return;
        }

        mobileNav.dataset.open = "false";
        body.classList.remove("nav-menu-open");
        syncMobileToggle(false);

        mobileHideTimer = window.setTimeout(() => {
            if (mobileNav.dataset.open !== "true") {
                mobileNav.hidden = true;
            }
        }, 260);
    };

    if (mobileToggle) {
        syncMobileToggle(false);
        mobileToggle.addEventListener("click", () => {
            const isOpen = mobileToggle.getAttribute("aria-expanded") === "true";
            setMobileMenuOpen(!isOpen);
        });
    }

    mobileCloseButtons.forEach((button) => {
        button.addEventListener("click", () => setMobileMenuOpen(false));
    });

    if (mobileNav) {
        mobileNav.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => setMobileMenuOpen(false));
        });
    }

    mobileGroups.forEach((group) => {
        group.addEventListener("toggle", () => {
            if (!group.open) return;

            mobileGroups.forEach((otherGroup) => {
                if (otherGroup !== group) {
                    otherGroup.open = false;
                }
            });
        });
    });

    desktopTriggers.forEach((trigger) => {
        trigger.addEventListener("keydown", (event) => {
            if (event.key === "Escape") {
                trigger.blur();
            }
        });
    });

    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
            setMobileMenuOpen(false);
        }
    });

    const handleViewportChange = (event) => {
        if (event.matches) {
            setMobileMenuOpen(false);
        }
    };

    if (typeof largeViewport.addEventListener === "function") {
        largeViewport.addEventListener("change", handleViewportChange);
    } else if (typeof largeViewport.addListener === "function") {
        largeViewport.addListener(handleViewportChange);
    }

    window.addEventListener("hashchange", syncActiveState);
    syncActiveState();
})();
